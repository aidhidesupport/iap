import type { Metadata } from 'next';
import { Guide, Section, DataTable } from '@/components/guide';
import { CodeBlock } from '@/components/code-block';
import { TextLink } from '@/components/site';
export const metadata:Metadata={title:'開発者ガイド — 導入から共有まで'};
export default function Developer(){return <Guide title="案件に導入し、作業の中で使う。" label="DEVELOPER GUIDE" lead="IAP × Codexは、開発者の案件フォルダーに導入するローカルの試作です。PMの依頼を作業記録にし、照合・修正・再確認・共有につなげます。" sections={ [['before','導入する前に'],['agree','依頼を記録する'],['install','配置・有効化する'],['work','作業と確認'],['share','PMへ共有する'],['pause','止める・戻る']] }>
<Section id="before" title="01 — 導入する前に"><p>このガイドは、試作コードの<code>iap-codex</code>フォルダーを受け取った方向けです。現在、公開GitHubには仕様草案を掲載しており、試作コードを一般配布するダウンロード導線はまだ用意していません。</p><DataTable headings={['用意するもの','確認すること']} rows={ [['Codexを使う開発環境','ログイン済みで、対象プロジェクトを開けること。初回の有効化はCLIで確認します。'],['Node.js','22.13以降。導入スクリプトに追加のAPIキーは不要です。'],['小さな案件と読む成果','最初は30〜60分の案件と、少数のUTF-8テキストファイル。'],['別の人が担当するPM','目的・完成条件・対象外を共有できること。']]}/><div className="callout neutral"><p>このページを開いても、案件への導入は行われません。以下のコマンドは、導入する端末のターミナルで実行します。</p></div></Section>
<Section id="agree" title="02 — PMの依頼を、作業記録にする"><p>PMから目的・完成条件・対象外を受け取り、開発者とCodexが<code>contract.json</code>を作ります。PMにJSONの編集を依頼する必要はありません。既存の案件の記録をそのまま流用せず、その依頼に合わせます。</p><DataTable headings={['項目','例']} rows={ [['目的','CSVの金額を集計し、正常・不正入力の結果を検証する。'],['完成条件','正常入力で合計600円。不正入力で2行目のエラーを報告する。'],['対象外','ログイン、認証、データベースの開発。'],['読む成果','検証報告のテキストファイル。'],['次の一手','指定した2入力を実行し、結果を記録する。']]}/><p>観測できるのは、指定したファイルだけです。1〜16ファイル、各64,000バイト以下のUTF-8テキストが対象です。画像・PDF・フォルダー全体を自動で理解する設定ではありません。</p><CodeBlock label="Codexへの依頼例">{`この案件にIAPを導入するため、作業記録JSONを作ってください。
PMの依頼：［依頼の文章］
目的：［目的］
完成条件：［成果で確認できる条件］
対象外：［今回は扱わないこと］
読むファイル：［案件フォルダーからの相対パス］
不明な条件は推測で確定せず、確認事項として残してください。`}</CodeBlock></Section>
<Section id="install" title="03 — 案件フォルダーに配置して、有効化する"><p>受け取った<code>iap-codex</code>フォルダーをターミナルで開きます。以下のパスを実際の案件フォルダーと作業記録JSONへ置き換えて実行してください。</p><CodeBlock>{`node manage.mjs install /path/to/project /path/to/contract.json
node manage.mjs doctor /path/to/project`}</CodeBlock><p>インストーラーが案件内に<code>.iap</code>の記録・照合スクリプト、<code>.codex/hooks.json</code>、<code>AGENTS.md</code>の作業指示を配置します。既存設定を保持し、変更前の内容をバックアップします。</p><p>次に、<strong>その案件フォルダーを対象に</strong>Codex CLIを開き、<code>/hooks</code>でIAPのフックをレビューして信頼します。対象プロジェクトの信頼確認が表示された場合も内容を確認します。新規・変更されたフックは信頼されるまで実行されません。<a href="https://learn.chatgpt.com/docs/hooks#review-and-trust-hooks">OpenAI公式の有効化手順</a></p><div className="callout"><p><strong>配置の確認と、動作の確認は別です。</strong><br/><code>doctor</code>の<code>configured: true</code>は、必要なファイルがそろっていることを示します。最後に小さな架空の依頼で、成果変更後の照合と共有文生成が動くことを確認してください。</p></div><p>導入先ごとに確認します。親フォルダーの別のタスクや、別の端末にも有効になったとは扱いません。</p></Section>
<Section id="work" title="04 — 作業を進め、ずれたら戻る"><ol><li>Codexが依頼と実際の成果を読み、完成条件と対象範囲を照合します。</li><li>範囲内で直せるものは、開発者側で実装・テスト・再確認を進めます。</li><li>目的・完成条件・範囲の変更に判断が必要なら、PMへの確認事項を切り出します。</li><li>評価を保存すると、共有文の下書きも生成されます。</li></ol><p>評価の<code>ready</code>は、条件達成の評価があるという状態です。PMが成果を受け入れたことや、Codexの意味判断が必ず正しいことを保証しません。</p></Section>
<Section id="share" title="05 — 最新の要約を、PMへ渡す"><p>共有する直前に、<strong>導入先の案件フォルダー</strong>で最新の要約を取得します。古い評価が失効していれば、未評価と表示します。</p><CodeBlock>{`node .iap/checkpoint.mjs share .`}</CodeBlock><p>目的・進捗・残り・次の一手・確認事項を読み、共有先に合わせて表現を整えてから、既存のチャット等へ貼り付けます。成果本文や実行ログは自動転載しませんが、自由記述の自動匿名化ではありません。</p><h3>試用の時間も記録する場合</h3><p>配布元の<code>iap-codex</code>フォルダーから実行します。<code>first-trial</code>は記録用のID例です。既に作成済みならinitを繰り返さず、shareから使います。</p><CodeBlock>{`node pilot.mjs init /path/to/project first-trial paired
node pilot.mjs share /path/to/project first-trial
node pilot.mjs report /path/to/project first-trial`}</CodeBlock><p>この共有コマンドは、要約の再観測・生成にかかった時間だけを記録します。手直し・送信操作・PMの確認時間は、本人たちが測った値を別に記録します。外部への送信は自動では行いません。</p></Section>
<Section id="pause" title="06 — 止める・再開する・困ったとき"><p>案件フォルダーで実行します。pauseはIAPの照合を休止し、resumeで再開します。Codex自体の中断とは別です。</p><CodeBlock>{`node .iap/checkpoint.mjs pause .
node .iap/checkpoint.mjs resume .
node .iap/checkpoint.mjs handoff .`}</CodeBlock><DataTable headings={['状態','確認すること']} rows={ [['フックが動かない','対象の案件でCodexを開いているか、/hooksで設定を信頼しているか。'],['評価が古い・成果が未観測','成果のパス・更新内容を確認し、Codexに再観測と再評価を依頼する。'],['導入時に既存設定の変更を検出','手作業の変更を上書きせず、差分とバックアップを確認する。'],['共有文を書けない','評価が保存済みかを確認し、shareで現在の要約を取り直す。']]}/><div className="guide-next"><TextLink href="/guide/pm">PM側の受け取り方</TextLink><TextLink href="/status">できること・未実装のこと</TextLink></div></Section>
</Guide>;}
