import { access, mkdir, rename, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

// vinext's current prerenderer follows slash redirects before exporting.
// Render without redirects, then use directory indexes for GitHub Pages.
const output = 'dist/client';
const routes = ['proposal', 'guide/developer', 'guide/pm', 'status', 'participate'];
for (const route of routes) {
  const source = join(output, `${route}.html`);
  await access(source);
  await mkdir(join(output, route), { recursive: true });
  await rename(source, join(output, route, 'index.html'));
}
// assetPrefix is a URL prefix; Pages itself supplies the repository prefix.
await rename(join(output, 'iap', '_next'), join(output, '_next'));
await access(join(output, 'index.html'));
await writeFile(join(output, '.nojekyll'), '');
console.log('Prepared 6 static pages for /iap/.');
