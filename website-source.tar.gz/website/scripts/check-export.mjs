import assert from 'node:assert/strict';
import { readFile, readdir, stat } from 'node:fs/promises';
import { join, resolve } from 'node:path';

const output = resolve('dist/client');
const prefix = '/iap/';
const routes = ['', 'proposal', 'guide/developer', 'guide/pm', 'status', 'participate'];
let checked = 0;
for (const route of routes) {
  const filename = join(output, route, 'index.html');
  const html = await readFile(filename, 'utf8');
  assert.match(html, /<html[^>]+lang="ja"/);
  assert.match(html, /<main\b/);
  for (const [, value] of html.matchAll(/(?:href|src|poster)="([^"]+)"/g)) {
    if (/^(?:https?:|data:|mailto:|tel:|\/\/)/.test(value)) continue;
    const url = new URL(value.replaceAll('&amp;', '&'), `https://aidhidesupport.github.io/iap/${route ? `${route}/` : ''}`);
    assert(url.pathname.startsWith(prefix), `${route}: missing project prefix: ${value}`);
    const pathname = decodeURIComponent(url.pathname.slice(prefix.length));
    let target = join(output, pathname);
    if (url.pathname.endsWith('/')) target = join(target, 'index.html');
    assert((await stat(target)).isFile(), `${route}: missing ${value}`);
    if (url.hash && target.endsWith('.html')) {
      const content = target === filename ? html : await readFile(target, 'utf8');
      const id = decodeURIComponent(url.hash.slice(1));
      assert(content.includes(`id="${id}"`), `${route}: missing fragment ${value}`);
    }
    checked++;
  }
}
const vtt = await readFile(join(output, 'media/iap-demo.vtt'), 'utf8');
assert(vtt.startsWith('WEBVTT\n'));
assert((await stat(join(output, 'media/iap-demo.mp4'))).size > 1_000_000);
assert((await readdir(output)).includes('.nojekyll'));
assert(!(await readdir(output)).includes('server'));
console.log(`Static export OK: ${routes.length} pages, ${checked} local references, video and captions.`);
