# IAPのホームページとガイド

partial-standardsの活動としてIAPを提案するWebサイト。GitHub Pagesのプロジェクトサイト `/iap/` へ静的ファイルとして配信する。

## ローカルで編集する

Node.js 22.13以降。

```sh
npm ci
npm run dev -- --host 127.0.0.1
```

開発サーバーの `/iap/` を開く。公開先も `/iap/`。サイト内リンクは `components/site-link.tsx`、画像・動画等は `lib/site-path.ts` の `publicAsset` を使う。配信時にサーバー処理を必要としない通常のページ遷移を使う。

```sh
npx tsc --noEmit
npm run build
node scripts/check-export.mjs
```

出力先は `dist/client`。サーバー・認証・データベースを必要としない。アプリの動的処理はコマンドをコピーするボタンのみで、データを外部へ送らない。

## 更新と公開

`main` にこのフォルダーの変更を反映すると、GitHub Actionsがビルド・リンク検査・公開を行う。リポジトリの Settings → Pages → Source は GitHub Actions を選ぶ。

公開資料はリポジトリ直下のMarkdown、Web案内はこのフォルダーで管理する。役割や実装の範囲を変更する場合は両方を更新する。

動画は架空ケースに基づく説明用の再構成。実案件の共同作業や専用アプリ画面の録画ではない。

## 公開条件と配布物

仕様・ガイドはCC BY 4.0、基本実装はApache-2.0。詳細はリポジトリ直下のRIGHTS.mdとLICENSE.mdを参照。`/participate/`に利用条件と参加案内を掲載する。`public/downloads/`に0.2.5の最小配布物とチェックサム、`public/licenses/`に利用条件と第三者のライセンスを収録する。公開動画は標準合成音声を除いた字幕付き版。
